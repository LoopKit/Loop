//
//  LoopCore.h
//  LoopCore
//
//  Copyright © 2019 LoopKit Authors. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for LoopCore.
FOUNDATION_EXPORT double LoopCoreVersionNumber;

//! Project version string for LoopCore.
FOUNDATION_EXPORT const unsigned char LoopCoreVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <LoopCore/PublicHeader.h>


