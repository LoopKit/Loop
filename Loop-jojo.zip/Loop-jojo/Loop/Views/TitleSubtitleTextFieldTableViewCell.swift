//
//  TitleSubtitleTextFieldTableViewCell.swift
//  Loop
//
//  Copyright © 2017 LoopKit Authors. All rights reserved.
//

import UIKit

class TitleSubtitleTextFieldTableViewCell: PredictionInputEffectTableViewCell {

    @IBOutlet weak var textField: UITextField!

}
