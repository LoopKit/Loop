//
//  CarbEntryEditTableViewController.swift
//  Naterade
//
//  Created by Nathan Racklyeft on 3/25/16.
//  Copyright © 2016 Nathan Racklyeft. All rights reserved.
//

import LoopKitUI
import LoopCore


extension CarbEntryEditViewController: IdentifiableClass {
}
