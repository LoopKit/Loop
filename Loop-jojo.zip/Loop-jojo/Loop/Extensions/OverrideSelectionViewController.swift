//
//  OverrideSelectionViewController.swift
//  Loop
//
//  Created by Michael Pangburn on 1/27/19.
//  Copyright © 2019 LoopKit Authors. All rights reserved.
//

import LoopCore
import LoopKitUI


extension OverrideSelectionViewController: IdentifiableClass { }
